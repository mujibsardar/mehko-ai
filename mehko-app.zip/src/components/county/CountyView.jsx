import React from "react";
import ApplicationSteps from "./ApplicationSteps";
import FormViewer from "./FormViewer";
import AIChat from "./AIChat";
import CommentsSection from "./CommentsSection";

function CountyView({ county }) {
  return (
    <div className="county-view">
      <h2>{county.name}</h2>
      <p>{county.description}</p>

      <ApplicationSteps
        steps={county.steps}
        requirements={county.requirements}
      />

      {county.formsEditable && <FormViewer forms={county.forms} />}
      {county.hasAiSupport && <AIChat county={county} />}
      {county.hasCommentThread && <CommentsSection county={county} />}
    </div>
  );
}

export default CountyView;
